package com.shkrivani.statecapitals

// data class

data class Capital(
    val state: String,
    val capitalCity: String
)