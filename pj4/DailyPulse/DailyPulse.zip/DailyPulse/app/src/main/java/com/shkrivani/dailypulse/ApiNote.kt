package com.shkrivani.dailypulse

data class ApiNote(
    val mood: String?,
    val note: String?
)