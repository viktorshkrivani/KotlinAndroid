package com.shkrivani.a4crypto

data class CryptoResponse(
    val data: List<Crypto>
)
